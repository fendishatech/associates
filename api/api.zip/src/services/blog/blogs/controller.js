export const getAuthors = (req, res) => {};

export const getAuthorById = (req, res) => {};

export const createAuthor = (req, res) => {};

export const updateAuthors = (req, res) => {};

export const deleteAuthors = (req, res) => {};

// class Polygon {
//   sayName() {
//     console.log("Hi, I am a class member");
//   }
// }

// export default Polygon;

import express from "express";

const routes = express.Router();

users.get("/me", () => "whatever");

module.exports = users;

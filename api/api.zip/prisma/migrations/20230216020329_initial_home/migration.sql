-- AlterTable
ALTER TABLE `authors` MODIFY `title` VARCHAR(191) NULL,
    MODIFY `jobPosition` VARCHAR(191) NULL;
